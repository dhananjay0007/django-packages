=======
Credits
=======

Original author: Jonathan Moss <jonathan.moss@snowballone.com.au>.

Current maintainers: the (mostly) nice people at `Polyconseil`_.

Contributors:

* Francis Reyes <francis.reyes@snowballone.com.au>


.. _Polyconseil: https://opensource.polyconseil.fr
