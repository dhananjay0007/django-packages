from django.apps import AppConfig


class CidAppConfig(AppConfig):
    name = 'cid'
    verbose_name = 'Django Correlation Id'
